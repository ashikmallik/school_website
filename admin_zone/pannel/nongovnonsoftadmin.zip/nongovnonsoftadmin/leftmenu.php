<div class="side-nav-inner">
                    <ul class="side-nav-menu scrollable">
                        

                 
                        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="dashBoard.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Dashboard</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                           
                        </li>
                        
                        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="institute_info.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Institute Info</span>
                                <!-- <span class="arrow">
                                <!--    <i class="arrow-icon"></i>-->
                                <!--</span> -->
                            </a>
                           
                        </li>
                        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="at_a_glance.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Infrastructure</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                        </li>
                    <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="teaching_permission.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Teaching Permission</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                            
                           
                        </li>
                                <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="nationalization_information.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Nationalization information</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                            
                           
                        </li> 
                    <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="governing_body.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Management Committee</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                            
                           
                        </li>         
                <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="former_headmaster.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Former Headmaster List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                            
                           
                        </li>                                             
                <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="teacher_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Teacher List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                </li>
                <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="class_teacher_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Class Teacher List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                </li>
            <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="staff_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Staff List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                </li>
        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="class_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Class List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                </li> 
        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="section_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Section List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
        </li> 
        <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="student_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Student List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
        </li>  
                <li class="nav-item dropdown ">
                            <a class="dropdown-toggle" href="post_list.php">
                                <span class="icon-holder">
                                   <img src="assets/images/fessicon/paymenthistory.svg" alt="">
                                </span>
                                <span class="title">Post List</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                            
                           
                        </li>        
                        
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="slider.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Slider</span>
                                <!-- <span class="arrow">
									<i class="arrow-icon"></i>
								</span> -->
                            </a>
                            
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="notice.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Notice</span>
                            </a>
                            
                        </li>
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="gallery.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Gallery</span>
                            </a>
                            
                        </li>
                        
                    <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="corner.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Corner</span>
                            </a>
                            
                        </li>
                                    <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="publication.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Publication</span>
                            </a>
                            
                        </li>    
                    <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="syllabus.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Syllabus</span>
                            </a>
                            
                        </li>      
                    <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="routine.php">
                                <span class="icon-holder">
									<img src="assets/images/fessicon/paymenthistory.svg" alt="">
								</span>
                                <span class="title">Routine</span>
                            </a>
                        </li>            
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" href="logout.php">
                                <span class="icon-holder">
                                   <img src="assets/images/log_out.png" alt="">
                                </span>
                                <span class="title">Logout</span>
                                <!-- <span class="arrow">
                                    <i class="arrow-icon"></i>
                                </span> -->
                            </a>
                           
                        </li>
                        
                    </ul>
                </div>